# Kalshi BTC 15-minute Paper Lab — accounting fix

## Safety
This is still a **paper-only** program. It reads public market data and never submits Kalshi Demo or Production orders. It does not request API keys.

## What changed
- Separates available cash from book equity.
- Displays reserved entry cost and estimated fee for an open position.
- Displays realized P/L separately from today's settled P/L.
- Uses a new `paper_trades_v2.csv` ledger so the previous CSV is preserved.
- Keeps existing `paper_state.json` and migrates its available-cash value without deleting an open position.
- Clarifies that the open position is carried at entry cost until settlement; it is not marked to a live resale value.
- Keeps the $100 starting bankroll and $2 maximum contract-cost setting. Fees are additional.

## Important before replacing files
1. Keep the existing bot stopped.
2. Download a backup copy of `paper_state.json` and `paper_trades.csv` from the GitHub repository if they exist.
3. Replace only `dashboard.py` and `kalshi_btc15_paper_bot.py` with these versions.
4. Do not delete `paper_state.json` or `paper_trades.csv`.
5. Commit the two replacements and let Streamlit redeploy.
6. Confirm the dashboard shows cash, equity, and the preserved open position correctly before pressing Start.

## Files
- `dashboard.py`
- `kalshi_btc15_paper_bot.py`
- `requirements.txt`

The heuristic confidence number is not a calibrated probability or evidence of a 90% win chance. Fee calculations are estimates; check current Kalshi fee rules before interpreting simulated returns.
